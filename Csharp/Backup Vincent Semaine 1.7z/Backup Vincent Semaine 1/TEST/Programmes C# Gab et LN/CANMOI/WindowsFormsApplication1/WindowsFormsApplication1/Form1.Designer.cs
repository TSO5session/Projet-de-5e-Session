﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.RECEVOIRGROUPBOX = new System.Windows.Forms.GroupBox();
            this.DEBUG = new System.Windows.Forms.Label();
            this.textBoxD7RX = new System.Windows.Forms.TextBox();
            this.textBoxD6RX = new System.Windows.Forms.TextBox();
            this.textBoxD5RX = new System.Windows.Forms.TextBox();
            this.textBoxD4RX = new System.Windows.Forms.TextBox();
            this.textBoxD3RX = new System.Windows.Forms.TextBox();
            this.textBoxD2RX = new System.Windows.Forms.TextBox();
            this.textBoxD1RX = new System.Windows.Forms.TextBox();
            this.textBoxD0RX = new System.Windows.Forms.TextBox();
            this.textBoxLONGEURRX = new System.Windows.Forms.TextBox();
            this.textBoxIDRX = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonLireRX = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxVitesseRX = new System.Windows.Forms.ComboBox();
            this.comboBoxCanalRX = new System.Windows.Forms.ComboBox();
            this.ConnecterRXBTN = new System.Windows.Forms.Button();
            this.groupBoxEnvoyer = new System.Windows.Forms.GroupBox();
            this.textBoxD7TX = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxD6TX = new System.Windows.Forms.TextBox();
            this.buttonConnecterTX = new System.Windows.Forms.Button();
            this.textBoxD5TX = new System.Windows.Forms.TextBox();
            this.comboBoxCanalTX = new System.Windows.Forms.ComboBox();
            this.textBoxD4TX = new System.Windows.Forms.TextBox();
            this.comboBoxVitesseTX = new System.Windows.Forms.ComboBox();
            this.textBoxD3TX = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxD2TX = new System.Windows.Forms.TextBox();
            this.buttonLireTX = new System.Windows.Forms.Button();
            this.textBoxD1TX = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxDOTX = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxLongeurTX = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxIDTX = new System.Windows.Forms.TextBox();
            this.RECEVOIRGROUPBOX.SuspendLayout();
            this.groupBoxEnvoyer.SuspendLayout();
            this.SuspendLayout();
            // 
            // RECEVOIRGROUPBOX
            // 
            this.RECEVOIRGROUPBOX.Controls.Add(this.DEBUG);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxD7RX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxD6RX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxD5RX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxD4RX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxD3RX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxD2RX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxD1RX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxD0RX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxLONGEURRX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.textBoxIDRX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.label5);
            this.RECEVOIRGROUPBOX.Controls.Add(this.label4);
            this.RECEVOIRGROUPBOX.Controls.Add(this.label3);
            this.RECEVOIRGROUPBOX.Controls.Add(this.buttonLireRX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.label2);
            this.RECEVOIRGROUPBOX.Controls.Add(this.label1);
            this.RECEVOIRGROUPBOX.Controls.Add(this.comboBoxVitesseRX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.comboBoxCanalRX);
            this.RECEVOIRGROUPBOX.Controls.Add(this.ConnecterRXBTN);
            this.RECEVOIRGROUPBOX.Location = new System.Drawing.Point(12, 12);
            this.RECEVOIRGROUPBOX.Name = "RECEVOIRGROUPBOX";
            this.RECEVOIRGROUPBOX.Size = new System.Drawing.Size(535, 239);
            this.RECEVOIRGROUPBOX.TabIndex = 0;
            this.RECEVOIRGROUPBOX.TabStop = false;
            this.RECEVOIRGROUPBOX.Text = "Recevoir";
            // 
            // DEBUG
            // 
            this.DEBUG.AutoSize = true;
            this.DEBUG.Location = new System.Drawing.Point(310, 20);
            this.DEBUG.Name = "DEBUG";
            this.DEBUG.Size = new System.Drawing.Size(41, 13);
            this.DEBUG.TabIndex = 19;
            this.DEBUG.Text = "label11";
            this.DEBUG.Click += new System.EventHandler(this.DEBUG_Click);
            // 
            // textBoxD7RX
            // 
            this.textBoxD7RX.Location = new System.Drawing.Point(349, 180);
            this.textBoxD7RX.Name = "textBoxD7RX";
            this.textBoxD7RX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD7RX.TabIndex = 18;
            // 
            // textBoxD6RX
            // 
            this.textBoxD6RX.Location = new System.Drawing.Point(310, 180);
            this.textBoxD6RX.Name = "textBoxD6RX";
            this.textBoxD6RX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD6RX.TabIndex = 17;
            // 
            // textBoxD5RX
            // 
            this.textBoxD5RX.Location = new System.Drawing.Point(271, 180);
            this.textBoxD5RX.Name = "textBoxD5RX";
            this.textBoxD5RX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD5RX.TabIndex = 16;
            // 
            // textBoxD4RX
            // 
            this.textBoxD4RX.Location = new System.Drawing.Point(232, 180);
            this.textBoxD4RX.Name = "textBoxD4RX";
            this.textBoxD4RX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD4RX.TabIndex = 15;
            // 
            // textBoxD3RX
            // 
            this.textBoxD3RX.Location = new System.Drawing.Point(193, 180);
            this.textBoxD3RX.Name = "textBoxD3RX";
            this.textBoxD3RX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD3RX.TabIndex = 14;
            // 
            // textBoxD2RX
            // 
            this.textBoxD2RX.Location = new System.Drawing.Point(154, 180);
            this.textBoxD2RX.Name = "textBoxD2RX";
            this.textBoxD2RX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD2RX.TabIndex = 13;
            // 
            // textBoxD1RX
            // 
            this.textBoxD1RX.Location = new System.Drawing.Point(115, 180);
            this.textBoxD1RX.Name = "textBoxD1RX";
            this.textBoxD1RX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD1RX.TabIndex = 12;
            // 
            // textBoxD0RX
            // 
            this.textBoxD0RX.Location = new System.Drawing.Point(76, 180);
            this.textBoxD0RX.Name = "textBoxD0RX";
            this.textBoxD0RX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD0RX.TabIndex = 11;
            // 
            // textBoxLONGEURRX
            // 
            this.textBoxLONGEURRX.Location = new System.Drawing.Point(75, 149);
            this.textBoxLONGEURRX.Name = "textBoxLONGEURRX";
            this.textBoxLONGEURRX.Size = new System.Drawing.Size(58, 20);
            this.textBoxLONGEURRX.TabIndex = 10;
            // 
            // textBoxIDRX
            // 
            this.textBoxIDRX.Location = new System.Drawing.Point(75, 117);
            this.textBoxIDRX.Name = "textBoxIDRX";
            this.textBoxIDRX.Size = new System.Drawing.Size(58, 20);
            this.textBoxIDRX.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 187);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Données:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Longeur:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "ID:";
            // 
            // buttonLireRX
            // 
            this.buttonLireRX.Location = new System.Drawing.Point(362, 95);
            this.buttonLireRX.Name = "buttonLireRX";
            this.buttonLireRX.Size = new System.Drawing.Size(75, 23);
            this.buttonLireRX.TabIndex = 5;
            this.buttonLireRX.Text = "LIRE";
            this.buttonLireRX.UseVisualStyleBackColor = true;
            this.buttonLireRX.Click += new System.EventHandler(this.buttonLireRX_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(193, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Vitesse";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Canal";
            // 
            // comboBoxVitesseRX
            // 
            this.comboBoxVitesseRX.FormattingEnabled = true;
            this.comboBoxVitesseRX.Location = new System.Drawing.Point(196, 57);
            this.comboBoxVitesseRX.Name = "comboBoxVitesseRX";
            this.comboBoxVitesseRX.Size = new System.Drawing.Size(121, 21);
            this.comboBoxVitesseRX.TabIndex = 2;
            this.comboBoxVitesseRX.SelectedIndexChanged += new System.EventHandler(this.comboBoxVitesseRX_SelectedIndexChanged);
            // 
            // comboBoxCanalRX
            // 
            this.comboBoxCanalRX.FormattingEnabled = true;
            this.comboBoxCanalRX.Location = new System.Drawing.Point(24, 57);
            this.comboBoxCanalRX.Name = "comboBoxCanalRX";
            this.comboBoxCanalRX.Size = new System.Drawing.Size(121, 21);
            this.comboBoxCanalRX.TabIndex = 1;
            this.comboBoxCanalRX.SelectedIndexChanged += new System.EventHandler(this.comboBoxCanalRX_SelectedIndexChanged);
            // 
            // ConnecterRXBTN
            // 
            this.ConnecterRXBTN.Location = new System.Drawing.Point(362, 55);
            this.ConnecterRXBTN.Name = "ConnecterRXBTN";
            this.ConnecterRXBTN.Size = new System.Drawing.Size(75, 23);
            this.ConnecterRXBTN.TabIndex = 0;
            this.ConnecterRXBTN.Text = "Connecter";
            this.ConnecterRXBTN.UseVisualStyleBackColor = true;
            this.ConnecterRXBTN.Click += new System.EventHandler(this.ConnecterRXBTN_Click);
            // 
            // groupBoxEnvoyer
            // 
            this.groupBoxEnvoyer.Controls.Add(this.textBoxD7TX);
            this.groupBoxEnvoyer.Controls.Add(this.label10);
            this.groupBoxEnvoyer.Controls.Add(this.textBoxD6TX);
            this.groupBoxEnvoyer.Controls.Add(this.buttonConnecterTX);
            this.groupBoxEnvoyer.Controls.Add(this.textBoxD5TX);
            this.groupBoxEnvoyer.Controls.Add(this.comboBoxCanalTX);
            this.groupBoxEnvoyer.Controls.Add(this.textBoxD4TX);
            this.groupBoxEnvoyer.Controls.Add(this.comboBoxVitesseTX);
            this.groupBoxEnvoyer.Controls.Add(this.textBoxD3TX);
            this.groupBoxEnvoyer.Controls.Add(this.label9);
            this.groupBoxEnvoyer.Controls.Add(this.textBoxD2TX);
            this.groupBoxEnvoyer.Controls.Add(this.buttonLireTX);
            this.groupBoxEnvoyer.Controls.Add(this.textBoxD1TX);
            this.groupBoxEnvoyer.Controls.Add(this.label8);
            this.groupBoxEnvoyer.Controls.Add(this.textBoxDOTX);
            this.groupBoxEnvoyer.Controls.Add(this.label7);
            this.groupBoxEnvoyer.Controls.Add(this.textBoxLongeurTX);
            this.groupBoxEnvoyer.Controls.Add(this.label6);
            this.groupBoxEnvoyer.Controls.Add(this.textBoxIDTX);
            this.groupBoxEnvoyer.Location = new System.Drawing.Point(12, 257);
            this.groupBoxEnvoyer.Name = "groupBoxEnvoyer";
            this.groupBoxEnvoyer.Size = new System.Drawing.Size(535, 257);
            this.groupBoxEnvoyer.TabIndex = 1;
            this.groupBoxEnvoyer.TabStop = false;
            this.groupBoxEnvoyer.Text = "Envoyer";
            // 
            // textBoxD7TX
            // 
            this.textBoxD7TX.Location = new System.Drawing.Point(352, 214);
            this.textBoxD7TX.Name = "textBoxD7TX";
            this.textBoxD7TX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD7TX.TabIndex = 37;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(24, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Canal";
            // 
            // textBoxD6TX
            // 
            this.textBoxD6TX.Location = new System.Drawing.Point(313, 214);
            this.textBoxD6TX.Name = "textBoxD6TX";
            this.textBoxD6TX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD6TX.TabIndex = 36;
            // 
            // buttonConnecterTX
            // 
            this.buttonConnecterTX.Location = new System.Drawing.Point(365, 89);
            this.buttonConnecterTX.Name = "buttonConnecterTX";
            this.buttonConnecterTX.Size = new System.Drawing.Size(75, 23);
            this.buttonConnecterTX.TabIndex = 19;
            this.buttonConnecterTX.Text = "Connecter";
            this.buttonConnecterTX.UseVisualStyleBackColor = true;
            this.buttonConnecterTX.Click += new System.EventHandler(this.buttonConnecterTX_Click);
            // 
            // textBoxD5TX
            // 
            this.textBoxD5TX.Location = new System.Drawing.Point(274, 214);
            this.textBoxD5TX.Name = "textBoxD5TX";
            this.textBoxD5TX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD5TX.TabIndex = 35;
            // 
            // comboBoxCanalTX
            // 
            this.comboBoxCanalTX.FormattingEnabled = true;
            this.comboBoxCanalTX.Location = new System.Drawing.Point(27, 91);
            this.comboBoxCanalTX.Name = "comboBoxCanalTX";
            this.comboBoxCanalTX.Size = new System.Drawing.Size(121, 21);
            this.comboBoxCanalTX.TabIndex = 20;
            this.comboBoxCanalTX.SelectedIndexChanged += new System.EventHandler(this.comboBoxCanalTX_SelectedIndexChanged);
            // 
            // textBoxD4TX
            // 
            this.textBoxD4TX.Location = new System.Drawing.Point(235, 214);
            this.textBoxD4TX.Name = "textBoxD4TX";
            this.textBoxD4TX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD4TX.TabIndex = 34;
            // 
            // comboBoxVitesseTX
            // 
            this.comboBoxVitesseTX.FormattingEnabled = true;
            this.comboBoxVitesseTX.Location = new System.Drawing.Point(199, 91);
            this.comboBoxVitesseTX.Name = "comboBoxVitesseTX";
            this.comboBoxVitesseTX.Size = new System.Drawing.Size(121, 21);
            this.comboBoxVitesseTX.TabIndex = 21;
            this.comboBoxVitesseTX.SelectedIndexChanged += new System.EventHandler(this.comboBoxVitesseTX_SelectedIndexChanged);
            // 
            // textBoxD3TX
            // 
            this.textBoxD3TX.Location = new System.Drawing.Point(196, 214);
            this.textBoxD3TX.Name = "textBoxD3TX";
            this.textBoxD3TX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD3TX.TabIndex = 33;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(196, 54);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Vitesse";
            // 
            // textBoxD2TX
            // 
            this.textBoxD2TX.Location = new System.Drawing.Point(157, 214);
            this.textBoxD2TX.Name = "textBoxD2TX";
            this.textBoxD2TX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD2TX.TabIndex = 32;
            // 
            // buttonLireTX
            // 
            this.buttonLireTX.Location = new System.Drawing.Point(365, 129);
            this.buttonLireTX.Name = "buttonLireTX";
            this.buttonLireTX.Size = new System.Drawing.Size(75, 23);
            this.buttonLireTX.TabIndex = 24;
            this.buttonLireTX.Text = "Ecrire";
            this.buttonLireTX.UseVisualStyleBackColor = true;
            this.buttonLireTX.Click += new System.EventHandler(this.buttonLireTX_Click);
            // 
            // textBoxD1TX
            // 
            this.textBoxD1TX.Location = new System.Drawing.Point(118, 214);
            this.textBoxD1TX.Name = "textBoxD1TX";
            this.textBoxD1TX.Size = new System.Drawing.Size(33, 20);
            this.textBoxD1TX.TabIndex = 31;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(21, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "ID:";
            // 
            // textBoxDOTX
            // 
            this.textBoxDOTX.Location = new System.Drawing.Point(79, 214);
            this.textBoxDOTX.Name = "textBoxDOTX";
            this.textBoxDOTX.Size = new System.Drawing.Size(33, 20);
            this.textBoxDOTX.TabIndex = 30;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 190);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "Longeur:";
            // 
            // textBoxLongeurTX
            // 
            this.textBoxLongeurTX.Location = new System.Drawing.Point(78, 183);
            this.textBoxLongeurTX.Name = "textBoxLongeurTX";
            this.textBoxLongeurTX.Size = new System.Drawing.Size(58, 20);
            this.textBoxLongeurTX.TabIndex = 29;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 221);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "Données:";
            // 
            // textBoxIDTX
            // 
            this.textBoxIDTX.Location = new System.Drawing.Point(78, 151);
            this.textBoxIDTX.Name = "textBoxIDTX";
            this.textBoxIDTX.Size = new System.Drawing.Size(58, 20);
            this.textBoxIDTX.TabIndex = 28;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(559, 526);
            this.Controls.Add(this.groupBoxEnvoyer);
            this.Controls.Add(this.RECEVOIRGROUPBOX);
            this.Name = "Form1";
            this.Text = "CAN";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.RECEVOIRGROUPBOX.ResumeLayout(false);
            this.RECEVOIRGROUPBOX.PerformLayout();
            this.groupBoxEnvoyer.ResumeLayout(false);
            this.groupBoxEnvoyer.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox RECEVOIRGROUPBOX;
        private System.Windows.Forms.TextBox textBoxD7RX;
        private System.Windows.Forms.TextBox textBoxD6RX;
        private System.Windows.Forms.TextBox textBoxD5RX;
        private System.Windows.Forms.TextBox textBoxD4RX;
        private System.Windows.Forms.TextBox textBoxD3RX;
        private System.Windows.Forms.TextBox textBoxD2RX;
        private System.Windows.Forms.TextBox textBoxD1RX;
        private System.Windows.Forms.TextBox textBoxD0RX;
        private System.Windows.Forms.TextBox textBoxLONGEURRX;
        private System.Windows.Forms.TextBox textBoxIDRX;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonLireRX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxVitesseRX;
        private System.Windows.Forms.ComboBox comboBoxCanalRX;
        private System.Windows.Forms.Button ConnecterRXBTN;
        private System.Windows.Forms.GroupBox groupBoxEnvoyer;
        private System.Windows.Forms.TextBox textBoxD7TX;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxD6TX;
        private System.Windows.Forms.Button buttonConnecterTX;
        private System.Windows.Forms.TextBox textBoxD5TX;
        private System.Windows.Forms.ComboBox comboBoxCanalTX;
        private System.Windows.Forms.TextBox textBoxD4TX;
        private System.Windows.Forms.ComboBox comboBoxVitesseTX;
        private System.Windows.Forms.TextBox textBoxD3TX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxD2TX;
        private System.Windows.Forms.Button buttonLireTX;
        private System.Windows.Forms.TextBox textBoxD1TX;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxDOTX;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxLongeurTX;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxIDTX;
        private System.Windows.Forms.Label DEBUG;

    }
}

