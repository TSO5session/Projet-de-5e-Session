// **************************Fichier.h
// Auteur:       Vincent Chouinard
// Date:         20 juillet 2014
// Version:      1.0
// Modification: Aucune
//
// Compilateur:  IAR 8.1
//
// Description:
// *****************************************************************************
//#include "_DeclarationGenerale.h" // Raccourcis Linguistiques utiles
//#include "ConversionKeilToIAR.h"  //
//#include "CLClavier.h"            // Pour utiliser le clavier
//#include "CLEcran.h"              // Pour utiliser l'�cran
//#include "stdio.h"                // Pour faire des printf

//LinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxTUX