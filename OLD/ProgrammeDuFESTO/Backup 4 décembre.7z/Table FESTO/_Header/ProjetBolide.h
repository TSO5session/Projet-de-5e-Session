// ************************** FICHIER: ProjetBolide.H  *************************
//
// Auteur:       Louis-Normand Ang-Houle, Hicham Safoine, Vincent Chouinard
// Date:         1 mai 2014
// Version:      1.0
// Modification: Aucune
//
// Compilateur:  IAR 8.1
//
// Description:
//
//
// *****************************************************************************
#include "DeclarationGenerale.h"

#include "CLVehicule.h"
#include "CLTest.h"

#ifndef PROJETBOLIDEH
   #define PROJETBOLIDEH

#endif
//LinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxLinuxTUX
